package com.wipro.hrms.model;

public class AudioPlayer implements Player{
	public void play()
	{
		System.out.println("The audio player plays good sound...");
	}
}
