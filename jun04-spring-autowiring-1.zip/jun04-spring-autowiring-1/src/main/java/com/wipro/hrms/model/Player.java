package com.wipro.hrms.model;

public interface Player {
	void play();
}
