package com.wipro.hrms.model;

public class VideoPlayer implements Player{
	public void play() {
		System.out.println("Video player plays very good movies...");
	}
}
